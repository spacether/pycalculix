This is Gmsh, an automatic three-dimensional finite element mesh generator with
built-in pre- and post-processing facilities.

Gmsh is distributed under the terms of the GNU General Public License. See the
LICENSE.txt and CREDITS.txt files for more information.

The tutorial/ directory contains the examples from the tutorial chapter in the
reference manual (http://geuz.org/gmsh/doc/texinfo/).  The demos/ directory
contains additional examples.
